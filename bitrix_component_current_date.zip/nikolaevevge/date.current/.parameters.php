<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
$arComponentParameters = array(
  "GROUPS" => array(),
  "PARAMETERS" => array(
    "TEMPLATE_FOR_DATE" => array(
      "PARENT" => "BASE",
      "NAME" => GetMessage("NIKOLAEVEVGE_DATE_CURRENT_PARAMETERS_TEMPLATE_FOR_DATE"),
      "TYPE" => "STRING",
      "MULTIPLE" => "N",
      "DEFAULT" => "Y-m-d",
    ),
  ),
);
